import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InMemoryCustomerRepository implements CustomerRepository {

    private Map<Integer, Customer> customers = new HashMap<>();
    private int nextId = 1;

    @Override
    public void save(Customer customer) {
        if (customer.getId() == 0) {
            customer.setId(nextId++);
        }
        customers.put(customer.getId(), customer);
    }

    @Override
    public void update(Customer customer) {
        if (customers.containsKey(customer.getId())) {
            customers.put(customer.getId(), customer);
        } else {
            throw new IllegalArgumentException("Customer with ID " + customer.getId() + " does not exist");
        }
    }

    @Override
    public void delete(Customer customer) {
        customers.remove(customer.getId());
    }

    @Override
    public Customer findById(int id) {
        return customers.get(id);
    }

    @Override
    public List<Customer> findAll() {
        return new ArrayList<>(customers.values());
    }

    public class Customer {

        private int id;
        private String name;
        private String email;
    
        // Constructors, getters, and setters
        public Customer() {}
    
        public Customer(String name, String email) {
            this.name = name;
            this.email = email;
        }
    
        // Getters and setters
        public int getId() {
            return id;
        }
    
        public void setId(int id) {
            this.id = id;
        }
    
        public String getName() {
            return name;
        }
    
        public void setName(String name) {
            this.name = name;
        }
    
        public String getEmail() {
            return email;
        }
    
        public void setEmail(String email) {
            this.email = email;
        }
    }
    
}
