import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductService {
    private Map<Integer, Product> products;

    public ProductService() {
        this.products = new HashMap<>();
    }

    // Create a new product
    public void createProduct(int id, String name, double price) {
        Product newProduct = new Product(id, name, price);
        products.put(id, newProduct);
    }

    // Retrieve a product by its ID
    public Product getProductById(int id) {
        return products.get(id);
    }

    // Retrieve all products
    public List<Product> getAllProducts() {
        return new ArrayList<>(products.values());
    }

    // Update the details of a product
    public void updateProduct(int id, String name, double price) {
        if (products.containsKey(id)) {
            Product product = products.get(id);
            product.setName(name);
            product.setPrice(price);
        } else {
            System.out.println("Product with ID " + id + " does not exist.");
        }
    }

    // Delete a product
    public void deleteProduct(int id) {
        if (products.containsKey(id)) {
            products.remove(id);
        } else {
            System.out.println("Product with ID " + id + " does not exist.");
        }
    }
}
