package com.ijse.pos.model;


public class Product {
    // Attributes
    private String name;
    private double price;
    private int quantity;

    // Constructors
    public Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Method to calculate total price
    public double getTotalPrice() {
        return price * quantity;
    }

    // Method to display product information
    public void display() {
        System.out.println("Product: " + name);
        System.out.println("Price: $" + price);
        System.out.println("Quantity: " + quantity);
        System.out.println("Total Price: $" + getTotalPrice());
    }

    // Main method for testing
    public static void main(String[] args) {
        // Creating a new product object
        Product product1 = new Product("Phone", 599.99, 5);

        // Displaying product information
        product1.display();
    }
}
