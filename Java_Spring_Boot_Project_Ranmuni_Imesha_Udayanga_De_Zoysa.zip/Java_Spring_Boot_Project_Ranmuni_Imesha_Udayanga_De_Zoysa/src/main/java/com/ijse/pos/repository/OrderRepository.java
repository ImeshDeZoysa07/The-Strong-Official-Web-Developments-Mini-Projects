package com.ijse.pos.repository;

public interface OrderRepository {
    List<Order> getAllOrders();
    Order getOrderById(int id);
    void addOrder(Order order);
    void updateOrder(Order order);
    void deleteOrder(int id);
}
