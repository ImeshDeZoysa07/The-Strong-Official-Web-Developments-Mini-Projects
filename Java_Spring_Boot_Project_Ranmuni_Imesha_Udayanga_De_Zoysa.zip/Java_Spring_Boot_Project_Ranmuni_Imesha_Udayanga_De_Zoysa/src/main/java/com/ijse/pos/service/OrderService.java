import java.util.ArrayList;
import java.util.List;

public class OrderService {
    private List<Order> orders;

    public OrderService() {
        this.orders = new ArrayList<>();
    }

    // Method to add an order
    public void addOrder(Order order) {
        orders.add(order);
    }

    // Method to remove an order
    public void removeOrder(Order order) {
        orders.remove(order);
    }

    // Method to get all orders
    public List<Order> getAllOrders() {
        return orders;
    }

    // Method to get orders by customer ID
    public List<Order> getOrdersByCustomerId(int customerId) {
        List<Order> customerOrders = new ArrayList<>();
        for (Order order : orders) {
            if (order.getCustomerId() == customerId) {
                customerOrders.add(order);
            }
        }
        return customerOrders;
    }

    // Method to calculate total order amount
    public double calculateTotalOrderAmount() {
        double totalAmount = 0.0;
        for (Order order : orders) {
            totalAmount += order.getTotalAmount();
        }
        return totalAmount;
    }

    // Other methods related to order service can be added here
}
