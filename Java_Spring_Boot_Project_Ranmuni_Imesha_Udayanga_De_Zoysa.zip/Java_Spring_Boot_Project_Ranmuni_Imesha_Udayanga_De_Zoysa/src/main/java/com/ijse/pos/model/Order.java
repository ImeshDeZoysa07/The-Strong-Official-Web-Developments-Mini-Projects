import java.util.ArrayList;
import java.util.List;

public class Order {
    private int orderId;
    private List<Item> items;

    public Order(int orderId) {
        this.orderId = orderId;
        this.items = new ArrayList<>();
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void removeItem(Item item) {
        items.remove(item);
    }

    public double calculateTotal() {
        double total = 0.0;
        for (Item item : items) {
            total += item.getPrice();
        }
        return total;
    }

    public void displayOrder() {
        System.out.println("Order ID: " + orderId);
        System.out.println("Items:");
        for (Item item : items) {
            System.out.println(item.getName() + " - $" + item.getPrice());
        }
        System.out.println("Total: $" + calculateTotal());
    }

    public static void main(String[] args) {
        // Example usage
        Order order = new Order(123);
        order.addItem(new Item("Shirt", 25.99));
        order.addItem(new Item("Pants", 39.99));
        order.addItem(new Item("Shoes", 59.99));

        order.displayOrder();
    }
}

class Item {
    private String name;
    private double price;

    public Item(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
}
