import java.util.ArrayList;
import java.util.List;

public class CustomerService {
    private List<Customer> customers;

    public CustomerService() {
        customers = new ArrayList<>();
    }

    // Method to add a new customer
    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    // Method to remove an existing customer
    public void removeCustomer(Customer customer) {
        customers.remove(customer);
    }

    // Method to retrieve a customer by their ID
    public Customer getCustomerById(int id) {
        for (Customer customer : customers) {
            if (customer.getId() == id) {
                return customer;
            }
        }
        return null; // Customer not found
    }

    // Method to retrieve all customers
    public List<Customer> getAllCustomers() {
        return customers;
    }

    // Method to update customer information
    public void updateCustomer(Customer customer) {
        // Assuming customer information can be updated
        // For example: customer.setName("New Name");
        // In a real-world scenario, this method would contain more logic.
    }
}
