package com.yourcompany.pos.service;

import com.ijse.pos.model.Order;
import com.ijse.pos.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private OrderService orderService;

    private Order order;

    @BeforeEach
    void setUp() {
        order = new Order();
        order.setId(1L);
        order.setDescription("Sample Order");
        order.setAmount(100.0);
    }

    @Test
    public void shouldReturnAllOrders() {
        List<Order> orders = Arrays.asList(order);
        when(orderRepository.findAll()).thenReturn(orders);

        List<Order> foundOrders = orderService.getAllOrders();

        assertNotNull(foundOrders);
        assertEquals(1, foundOrders.size());
        assertEquals(order.getDescription(), foundOrders.get(0).getDescription());
    }

    @Test
    public void shouldReturnOrderById() {
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));

        Order foundOrder = orderService.getOrderById(1L);

        assertNotNull(foundOrder);
        assertEquals(order.getDescription(), foundOrder.getDescription());
    }

    @Test
    public void shouldThrowExceptionWhenOrderNotFoundById() {
        when(orderRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            orderService.getOrderById(1L);
        });
    }

    @Test
    public void shouldCreateOrder() {
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        Order createdOrder = orderService.createOrder(order);

        assertNotNull(createdOrder);
        assertEquals(order.getDescription(), createdOrder.getDescription());
    }

    @Test
    public void shouldUpdateOrder() {
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        Order updatedOrder = orderService.updateOrder(1L, order);

        assertNotNull(updatedOrder);
        assertEquals(order.getDescription(), updatedOrder.getDescription());
    }

    @Test
    public void shouldThrowExceptionWhenUpdatingNonExistentOrder() {
        when(orderRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            orderService.updateOrder(1L, order);
        });
    }

    @Test
    public void shouldDeleteOrder() {
        doNothing().when(orderRepository).deleteById(anyLong());

        assertDoesNotThrow(() -> orderService.deleteOrder(1L));

        verify(orderRepository, times(1)).deleteById(1L);
    }
}
