package com.yourcompany.pos.controller;

import com.ijse.pos.model.Order;
import com.ijse.pos.service.OrderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(OrderController.class)
public class OrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrderService orderService;

    private Order order;

    @BeforeEach
    void setUp() {
        order = new Order();
        order.setId(1L);
        order.setDescription("Sample Order");
        order.setAmount(100.0);
    }

    @Test
    public void shouldReturnAllOrders() throws Exception {
        List<Order> orders = Arrays.asList(order);
        when(orderService.getAllOrders()).thenReturn(orders);

        mockMvc.perform(get("/api/orders"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].description").value(order.getDescription()))
                .andExpect(jsonPath("$[0].amount").value(order.getAmount()));
    }

    @Test
    public void shouldReturnOrderById() throws Exception {
        when(orderService.getOrderById(anyLong())).thenReturn(order);

        mockMvc.perform(get("/api/orders/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.description").value(order.getDescription()))
                .andExpect(jsonPath("$.amount").value(order.getAmount()));
    }

    @Test
    public void shouldCreateOrder() throws Exception {
        when(orderService.createOrder(any(Order.class))).thenReturn(order);

        mockMvc.perform(post("/api/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"description\":\"Sample Order\",\"amount\":100.0}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.description").value(order.getDescription()))
                .andExpect(jsonPath("$.amount").value(order.getAmount()));
    }

    @Test
    public void shouldUpdateOrder() throws Exception {
        when(orderService.updateOrder(anyLong(), any(Order.class))).thenReturn(order);

        mockMvc.perform(put("/api/orders/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"description\":\"Updated Order\",\"amount\":150.0}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.description").value(order.getDescription()))
                .andExpect(jsonPath("$.amount").value(order.getAmount()));
    }

    @Test
    public void shouldDeleteOrder() throws Exception {
        mockMvc.perform(delete("/api/orders/1"))
                .andExpect(status().isOk());
    }
}
