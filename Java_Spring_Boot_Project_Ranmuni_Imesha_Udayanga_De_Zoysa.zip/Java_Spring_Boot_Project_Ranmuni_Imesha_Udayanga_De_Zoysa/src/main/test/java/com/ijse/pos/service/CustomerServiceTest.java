package com.yourcompany.pos.service;

import com.ijse.pos.model.Customer;
import com.ijse.pos.repository.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CustomerServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerService customerService;

    private Customer customer;

    @BeforeEach
    void setUp() {
        customer = new Customer();
        customer.setId(1L);
        customer.setName("John Doe");
        customer.setEmail("john.doe@example.com");
    }

    @Test
    public void shouldReturnAllCustomers() {
        List<Customer> customers = Arrays.asList(customer);
        when(customerRepository.findAll()).thenReturn(customers);

        List<Customer> foundCustomers = customerService.getAllCustomers();

        assertNotNull(foundCustomers);
        assertEquals(1, foundCustomers.size());
        assertEquals(customer.getName(), foundCustomers.get(0).getName());
    }

    @Test
    public void shouldReturnCustomerById() {
        when(customerRepository.findById(anyLong())).thenReturn(Optional.of(customer));

        Customer foundCustomer = customerService.getCustomerById(1L);

        assertNotNull(foundCustomer);
        assertEquals(customer.getName(), foundCustomer.getName());
    }

    @Test
    public void shouldThrowExceptionWhenCustomerNotFoundById() {
        when(customerRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            customerService.getCustomerById(1L);
        });
    }

    @Test
    public void shouldCreateCustomer() {
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);

        Customer createdCustomer = customerService.createCustomer(customer);

        assertNotNull(createdCustomer);
        assertEquals(customer.getName(), createdCustomer.getName());
    }

    @Test
    public void shouldUpdateCustomer() {
        when(customerRepository.findById(anyLong())).thenReturn(Optional.of(customer));
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);

        Customer updatedCustomer = customerService.updateCustomer(1L, customer);

        assertNotNull(updatedCustomer);
        assertEquals(customer.getName(), updatedCustomer.getName());
    }

    @Test
    public void shouldThrowExceptionWhenUpdatingNonExistentCustomer() {
        when(customerRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            customerService.updateCustomer(1L, customer);
        });
    }

    @Test
    public void shouldDeleteCustomer() {
        doNothing().when(customerRepository).deleteById(anyLong());

        assertDoesNotThrow(() -> customerService.deleteCustomer(1L));

        verify(customerRepository, times(1)).deleteById(1L);
    }
}
